#include <iostream>
using namespace std;

int main() {

    float  fahrenheit;
    float  celcius;

    cout << "Fahrenheit : ";
    cin >> fahrenheit;
    celcius = 5.0/9.0 * (fahrenheit - 32);
    cout << "Celcius   : " << celcius << endl; 
}